NEXORA — Android Studio project (paper trading)

Що є:
- Android WebView оболонка для Pixel / Android 8+
- Binance-подібний темний інтерфейс
- Віртуальний баланс $10,000 + поповнення по $1,000
- Spot Market buy/sell, Limit orders
- Futures Long/Short з плечем 1–20x
- Stop Loss / Take Profit, закриття позицій, PnL
- Локальне збереження портфеля через localStorage
- Публічні котирування криптовалют Binance
- Окремий WebSocket канал котирувань акцій Binance Equity (може бути недоступний у деяких мережах/регіонах)

ВАЖЛИВО:
- Це симулятор. Немає реальних депозитів, виведення чи біржових угод.
- Stock quotes are best-effort and may be unavailable. Не трактуйте відсутність котирувань як нульову ціну.
- Ф'ючерсна ліквідація спрощена навчальна модель.
- Усі угоди зберігаються локально на пристрої. Очищення даних програми стирає портфель.

Як зібрати APK:
1. Відкрити цю папку у Android Studio.
2. Дочекатися Gradle Sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK з'явиться в app/build/outputs/apk/debug/app-debug.apk

Вимоги: Android Studio з Android SDK Platform 35 та JDK 17.
